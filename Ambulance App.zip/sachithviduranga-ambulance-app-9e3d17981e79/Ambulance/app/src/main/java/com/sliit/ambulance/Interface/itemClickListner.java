package com.sliit.ambulance.Interface;

import android.view.View;

public interface itemClickListner {

    void onClick(View view, int position, boolean isLongClick);

}
